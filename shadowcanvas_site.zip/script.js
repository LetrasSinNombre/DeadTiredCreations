// ShadowCanvas original JS (only if needed later)
document.addEventListener("DOMContentLoaded", () => {
  console.log("Welcome to ShadowCanvas — your exclusive digital domain.");
});
